-- =====================================================================================
--  Migration du socle comptable — rend la frontière officiel / extension exprimable.
--  Sans ces deux colonnes, l'expert ne sait pas ce qu'il a le droit de modifier,
--  et le produit ne peut fonder aucune garantie de conformité.
-- =====================================================================================
alter table ref.accounts
  add column if not exists is_official boolean not null default false,
  add column if not exists source_ref  text;

comment on column ref.accounts.is_official is
  'true = verbatim NC 01 (nomenclature officielle SCE), non modifiable. '
  'false = subdivision ouverte par Regalica, ajustable par l''expert.';

-- Un compte officiel ne se modifie pas par le chemin de paramétrage.
create or replace function ref.proteger_comptes_officiels() returns trigger
language plpgsql as $$
begin
  if OLD.is_official and (
       NEW.account_code  is distinct from OLD.account_code or
       NEW.label         is distinct from OLD.label        or
       NEW.parent_code   is distinct from OLD.parent_code  or
       NEW.account_class is distinct from OLD.account_class or
       NEW.is_official   is distinct from OLD.is_official)
  then
    raise exception
      'Le compte % est officiel (NC 01) : son code, son libellé et son rattachement sont '
      'verbatim et ne peuvent pas être modifiés. Ouvrez une subdivision d''extension.',
      OLD.account_code
      using errcode = 'insufficient_privilege';
  end if;
  return NEW;
end $$;

drop trigger if exists trg_proteger_comptes_officiels on ref.accounts;
create trigger trg_proteger_comptes_officiels
  before update on ref.accounts
  for each row execute function ref.proteger_comptes_officiels();
