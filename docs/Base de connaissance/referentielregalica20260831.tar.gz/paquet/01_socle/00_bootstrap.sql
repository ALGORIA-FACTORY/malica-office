-- =====================================================================================
--  Bootstrap minimal — ne sert QU'À VÉRIFIER les seeds hors du dépôt.
--  Dans regalica-office, ref.jurisdiction_packs et ref.accounts existent déjà :
--  ce fichier n'est alors PAS joué, seules les colonnes ajoutées le sont (01_migration).
-- =====================================================================================
create schema if not exists ref;
create schema if not exists legal;
create extension if not exists pgcrypto;
create extension if not exists btree_gist;

create table if not exists ref.jurisdiction_packs (
  id uuid primary key default gen_random_uuid(),
  jurisdiction text not null,
  referentiel  text not null,
  version      text not null,
  unique (jurisdiction, referentiel, version)
);
insert into ref.jurisdiction_packs (jurisdiction, referentiel, version)
values ('TN','SCE','1997') on conflict do nothing;

create table if not exists ref.accounts (
  id uuid primary key default gen_random_uuid(),
  pack_version_id uuid not null references ref.jurisdiction_packs(id),
  account_code    text not null,
  label           text not null,
  parent_code     text,
  account_class   int  not null,
  normal_side     text check (normal_side in ('debit','credit')),
  is_collective   boolean not null default false,
  requires_auxiliary boolean not null default false,
  unique (pack_version_id, account_code)
);
