# Le corpus juridique tunisien — inventaire vérifié et file d'ingestion

**Statut :** adopté
**Date :** 2026-08-31
**Portée :** ce qu'il y a à ingérer, dans quel ordre, et ce qui casserait le pipeline

---

## 0. Ce qui a été fait, et ce qui ne l'a pas été

**Les 686 notes communes n'ont pas été lues.** Ce qui a été fait est différent, et c'était le
préalable : le **catalogue exhaustif et vérifié** de ce qu'il faut lire. Chaque URL a répondu,
chaque langue a été **mesurée sur le fichier** — extraction du texte puis détection de script
sur les scans — et non déduite du libellé du lien.

Lire 686 notes communes n'est pas un travail de conversation : c'est un **traitement par lots**
qui tourne dans le produit, avec une file, un statut et une reprise. Le schéma et le prompt de
segmentation existent pour ça. Ce document fournit la file.

## 1. Le compte réel : 688, pas 652

Le chiffre de 652 n'est pas faux, il est **périmé**. En triant le catalogue par date de mise en
ligne, il franchit 652 le **26 août 2024**. Depuis, 34 notes ont été ajoutées.

| | |
|---|---|
| Notes communes indexées par taxonomie | **686** |
| Notes communes publiées **hors taxonomie** — invisibles à tout crawl par catégorie | **2** |
| **Total réel** | **688** |
| Lois de finances, LFC et décrets-lois de finances, 1978 → 2026 | **68** |
| Éditions consolidées des codes | **32** |
| Conventions de non-double imposition | **58** |
| **File d'ingestion totale** | **788 documents** |

Répartition des notes communes par année, de 2002 à 2026 : 54, 45, 40, 39, 21, 33, 29, 23, 30,
22, 28, 31, 28, 19, 33, 24, 27, 27, 20, 18, 23, 20, 21, 15, 17.

## 2. L'ordre d'ingestion n'est pas chronologique

La prescription fiscale de droit commun borne ce qui est opposable. Une note commune de 2004 a
une valeur historique, pas opérationnelle. **Ingérer 686 notes n'est pas la priorité — ingérer
les bonnes l'est.**

| Priorité | Contenu | Documents |
|---|---|---|
| **1** | Éditions consolidées 2025-2026 des codes — *c'est la loi applicable* | 12 |
| **2** | Lois de finances 2021-2026 — *ce qui amende cette loi* | 9 |
| **3** | Notes communes 2021-2026 — *la doctrine encore opposable* | 114 |
| 4 | Notes communes antérieures à 2021 — archive | 574 |
| 5 | Lois de finances et éditions de codes antérieures — archive | 79 |

**Les 135 documents des priorités 1 à 3 couvrent tout ce dont le moteur a besoin aujourd'hui.**
Les 653 autres sont un chantier de fond, utile pour l'explication historique et la recherche,
sans effet sur la justesse d'une écriture de 2026.

## 3. Ce que le pipeline doit savoir avant d'être écrit

Ces points ont coûté une exploration complète du portail. Les ignorer coûterait plusieurs jours.

**L'URL du PDF n'est pas dérivable.** Le répertoire est régulier —
`/wp-content/uploads/{AAAA}/{MM}/` — mais `{AAAA}/{MM}` est le mois de **versement**, sans
rapport avec l'année de la note : 638 des 685 fichiers sont sous `2024/02`. Les noms suivent
quatre motifs incompatibles, 633 portent un suffixe de doublon WordPress, et 17 sont hors
motif. **L'URL doit être extraite du contenu de la fiche, jamais construite.**

**Les pages HTML de catégorie sont inutilisables pour compter.** La liste est rendue côté
client depuis un dump global : la page « notes communes » et la page « notes communes 2026 »
renvoient exactement les mêmes 808 liens. Seule l'API REST donne un compte exact.

**Le flux de veille évident ne se déclenchera jamais.** Le terme parent « notes communes »
n'a aucun document attaché — son compte est zéro et son flux RSS est vide. La veille passe par
le paramètre `modified_after` de l'API REST, ou par le sitemap et son `lastmod`.

**Les slugs d'année n'ont pas de convention stable** — `nc_2026`, `2025`, `2024`,
`2022-notes-communes`, `2017-notes-communes`. Le slug du millésime suivant est imprévisible :
il faut résoudre l'année par l'arbre des catégories, jamais en construisant le slug.

**102 PDF sur 685 n'ont aucune couche texte** — des scans, concentrés sur 2015-2023 : trois
quarts de l'exercice 2020, la moitié de 2016. Un OCR **bilingue français-arabe** est
obligatoire, sinon 15 % du corpus est muet.

**La date affichée ne signifie pas ce qu'elle dit.** 638 des 685 PDF ont été versés en février
2024, lors d'un import de masse. Pour 2002-2023, la date de mise en ligne n'a **aucune valeur
juridique**, et la date de signature de la note n'existe nulle part en métadonnée structurée.

**Volume total :** 5 200 pages, 333 Mo. Aucune limitation de débit observée sur 685 requêtes
en parallèle. Le `robots.txt` n'interdit ni `/docs/`, ni `/wp-content/uploads/`, ni `/wp-json/`.

## 4. Le basculement vers l'arabe

C'est le fait le plus important pour la suite, et il s'accélère :

| Millésime | Notes en arabe uniquement |
|---|---|
| 2024 | 8 sur 21 |
| 2025 | 8 sur 15 |
| **2026** | **17 sur 17** |

**Un pipeline français perdrait la totalité du millésime 2026.** Il perdrait aussi la LF 2026,
qui n'est publiée qu'en arabe par les deux portails fiscaux.

Une trouvaille compense en partie : le **JORT publie une traduction française officielle de la
LF 2026**, 161 pages en texte réel, là où les portails fiscaux ne servent que l'arabe. C'est la
seule source française complète sur toute la période.

## 5. Anomalies à traiter, pas à découvrir en production

- **1 lien mort** — la version arabe de la NC 02/2025 répond 404. Elle reste dans la file, sans
  URL exploitable, pour que la lacune ne disparaisse pas.
- **1 fiche vide** — la NC 6/2014 est publiée sans aucun PDF attaché.
- **2 notes hors taxonomie** — invisibles à tout parcours par catégorie. L'une est un doublon
  de la NC 1/2018, l'autre la version arabe de la NC 02/2025.
- **1 document de test en production** — une fiche intitulée « test », à filtrer.
- **5 paires de doublons stricts** — même année, même numéro, même titre, deux PDF distincts.
  À arbitrer manuellement : les fichiers ne sont pas forcément identiques.
- **Numérotation non contiguë** — 2020 saute de la note 19 à la note 28. Un contrôle de
  complétude fondé sur « 1 à max » produirait une trentaine de faux positifs. **Un trou de
  numérotation n'est pas une note manquante.**
- **Deux fiches de lois de finances cassées** — la fiche « LF 2000 » sert le fichier de la
  LF 2022 ; une fiche « LF 2018 » sert une convention fiscale.
- **Le vocabulaire bascule en 2021** de « loi de finances complémentaire » à « rectificative ».
  Filtrer sur « complémentaire » perd 2021, 2022 et 2023.
- **Les PDF de lois de finances 2001-2005 ont un encodage corrompu** — décalage de trois
  caractères, tous les chiffres perdus. Numéros et dates irrécupérables sans OCR.
- **Cinq textes de finances sont passés par décret-loi**, pas par loi. Les manquer, c'est
  manquer la LF 2022 et la LF 2023.

## 6. Ce qui n'existe pas, et qu'il ne faut pas chercher

- **Les prises de position ne sont pas publiées.** Aucun type de contenu, aucune taxonomie,
  aucun document sur le portail. Ce qu'une recherche renvoie sous ce nom, ce sont des notes
  communes dont le corps contient l'expression. Cela confirme par un autre chemin la
  conclusion juridique : une prise de position n'est ni publiée, ni opposable.
- **Aucune liste concurrente au ministère.** Le site du ministère des Finances ne publie pas
  d'inventaire ; son lien « Documentation Fiscale » pointe vers ce même portail. Il n'y a donc
  pas de source à réconcilier.

## 7. Limites assumées

- L'inventaire des lois de finances remonte à l'exercice **1978**. Au-delà, l'OCR du portail
  est trop bruité pour être fiable. Les exercices **1981 et 1993** sont identifiés par les
  codes mais leur fascicule JORT n'a pas été confirmé.
- Le contenu des 788 documents n'a **pas** été lu. Seuls les cinq corpus consolidés 2026 l'ont
  été, pour en extraire les 454 paramètres livrés au chantier fiscal.
- Les 58 conventions de non-double imposition sont cataloguées mais absentes de la file : leur
  ingestion suppose d'abord de trancher le statut de la convention Tunisie-Allemagne, dont le
  document en circulation porte une date de signature laissée en blanc.
