# La couche fiscale — architecture et état des lieux

**Statut :** adopté
**Date :** 2026-08-30
**Portée :** paramètres fiscaux, corpus juridique, calendrier des obligations, interface avec le socle comptable

---

## 0. Ce qui a été lu

Cinq lectures sur texte primaire, éditions **2026** :

| Corpus | Source | Paramètres extraits |
|---|---|---|
| Code de la TVA | jibaya.tn, éd. 2026 (arabe) + éd. 2023 (française) en contrôle | 77 |
| Code de l'IRPP et de l'IS | éd. 2026 intégrant la LF n° 2025-17 du 12/12/2025 | 211 |
| CDET (timbre, enregistrement), CFL, textes non incorporés | éditions 2026 | 107 |
| CNSS | loi n° 60-30 et ses décrets, lus **au JORT** | 62 |
| CDPF, LF 2026, doctrine, conventions | CDPF 2025, LF 2026, art. 54 LFC 2012 | 43 obligations |

**454 paramètres** et **43 obligations déclaratives** chargés, chacun avec son article et un
extrait littéral. Chargés, testés et vérifiés sur PostgreSQL 16.

---

## 1. Deux objets, jamais confondus

```
ref.fiscal_parameters   ce qui CALCULE     taux, seuils, barèmes, délais
                        machine-lisible    clé : PAYS + date

legal.articles          ce qui JUSTIFIE    le texte, versionné à l'article
legal.article_versions  cité, jamais calculé   clé : identité d'article + version
```

Le lien entre les deux est la citation portée par chaque paramètre. C'est la règle **R2**
— « aucun montant sans citation » — appliquée au fiscal, et elle est tenue par une contrainte
de base, pas par une convention :

```sql
constraint fiscal_param_citation
  check (confiance <> 'confirme' or (article is not null and citation is not null))
```

Testé : une insertion de taux sans article est refusée par PostgreSQL.

## 2. Trois clés distinctes, à ne jamais fusionner

| Objet | Clé | Pourquoi |
|---|---|---|
| Plan comptable | **référentiel** (SCE, PCG, SYSCOHADA) | L'OHADA, c'est dix-sept pays pour un seul plan |
| Paramètres fiscaux | **pays** | Trois pays OHADA partagent le plan, pas la TVA |
| Régime du dossier | **période**, portée par le dossier | Une société change de régime ; ce n'est pas un champ |

La **région** n'est pas une dimension comptable ni fiscale. Ce qui est régional en Tunisie —
les avantages des zones de développement — relève de NC 12 §03 : avantages sans transfert de
ressources, « *ne font pas l'objet d'un traitement comptable* ». Ils vont en note, pas en
écriture. Le débat est clos par le texte.

## 3. L'échelle d'un nombre n'est jamais implicite

C'est le piège que la lecture a révélé, et il aurait produit des erreurs d'un facteur cent.
Les trois lectures ont employé **trois conventions différentes** dans la même colonne :

| Le texte écrit | Naïvement chargé | Valeur juste |
|---|---|---|
| « 19 % » (TVA) | 0.19 | 0.19 |
| « 0,2 % du chiffre d'affaires » (minimum d'impôt, TCL) | **0.2** | **0.002** |
| « 2 pour mille » (plafond des dons) | 0.2 | 0.002 |
| « 1,000 dinar par facture » (timbre) | **1000** | **1.0** |

Le dinar a trois décimales. Dans un texte fiscal tunisien la virgule est **toujours**
décimale — « 1,000 dinar » est **un** dinar, et le singulier du texte le confirme.

D'où trois colonnes, pas une : `valeur_brute` conserve la graphie officielle pour l'audit,
`valeur_num` porte la forme canonique, `echelle` dit laquelle. **Le socle ne lit jamais
`valeur_brute` pour calculer.** 129 conversions ont été appliquées et sont toutes tracées.

## 4. Aucun taux deviné

Jumelle exacte de « aucun compte deviné ». `ref.parametre_fiscal(pays, code, date)` :

- trouvé et confirmé → la valeur ;
- trouvé mais non établi sur source officielle → **erreur** nommant le paramètre ;
- absent, ou hors période → **erreur**, jamais une extrapolation.

Testé : les trois refus se déclenchent, avec un message qui nomme le paramètre.

Et la résolution se fait sur la **date de la pièce**, pas la date du jour. Une facture du
15 janvier est jugée par la règle en vigueur le 15 janvier, même si le paramètre a été
chargé en mars.

Deux versions d'un même paramètre ne peuvent pas se chevaucher : une contrainte d'exclusion
GiST sur `daterange` l'interdit en base. Testé.

## 5. L'échéance dépend du mode de dépôt, pas seulement de la forme juridique

Découverte de la lecture, vérifiée dans **quatre codes indépendants** — art. 18-IV-1 CTVA,
art. 52-IV CIRPPIS, art. 39-II CFL, art. 119-III CDET :

| Redevable | Délai |
|---|---|
| Personne physique | 15 premiers jours du mois suivant |
| Personne morale, dépôt papier | 28 premiers jours |
| Personne morale **télédéclarante** | **20 premiers jours** |

C'est une **réduction** du délai, introduite par la LF 2024, et non une faveur. Un calendrier
qui ne modélise pas le mode de dépôt fait rater des échéances à ceux qui ont fait l'effort
de se moderniser.

## 6. L'autorité n'est pas un rang

Un entier `norm_level` écrase la distinction qui décide de tout. Ce que les textes disent :

| Source | Autorité | Opposable à | Fondement |
|---|---|---|---|
| Convention internationale | normative | tous | Constitution 2022, art. 74 |
| Loi, loi de finances | normative | tous | La LF est une loi ordinaire : même rang, prime par *lex posterior* |
| Décret, arrêté | normative | tous | — |
| **Note commune** | **interprétative** | **l'administration seule** | **Art. 54 LFC 2012** |
| **Prise de position** | interprétative | **personne** | **Aucun fondement identifié** |

> *[TEXTE] Art. 54 de la loi n° 2012-1 du 16 mai 2012 :* « Est opposable aux services de
> l'administration fiscale et du recouvrement la doctrine administrative en vigueur objet
> des notes communes émanant d'elle ayant fait l'objet de publication et relatives aux
> législations en vigueur. »

Quatre conditions cumulatives, plus étroites que l'article L80 A français : support limité
aux notes communes, publication requise, doctrine **en vigueur** — le texte ne protège pas
contre un revirement appliqué rétroactivement —, et sous condition de légalité.

Conséquence produit directe : **les notes communes doivent être horodatées et versionnées**,
et une prise de position ne doit jamais être présentée comme du droit.

## 7. Le contrat avec la couche comptable

**Aucun taux dans la couche comptable. Aucun numéro de compte dans la couche fiscale.**

Le fiscal fournit des valeurs et des qualifications — taux, régime, déductibilité, base.
Le comptable décide l'écriture. Les 35 schémas comptables référencent des *grandeurs*
(`montant_ht`, `tva`, `timbre`, `rs`) que le socle résout auprès de cette couche.

Les frontières trompeuses, celles où ça fuit :

| Question | Couche |
|---|---|
| Taux de TVA | fiscale |
| TVA non récupérable → incorporée au coût du bien | **comptable** — NC 04 §12 |
| Taux de retenue à la source | fiscale |
| La retenue opérée se loge au crédit du 432 | **comptable** |
| Durée d'utilité d'une immobilisation | **comptable** — NC 05 |
| Taux d'amortissement admis en déduction | fiscale |

C'est parce que ces deux dernières divergent qu'existe le tableau de détermination du
résultat fiscal. Deux couches proprement séparées le **génèrent** au lieu de le faire taper
à la main chaque année.

## 8. Ce que la lecture n'a pas établi

Treize paramètres sont en base avec `confiance = 'non_trouve'`. Ils y sont **pour que
l'absence soit visible**, et une contrainte leur interdit de porter une valeur. Les plus
gênants :

- **Contribution Sociale de Solidarité** — taux, base et champ non établis. À reprendre.
- **Taux maximum d'amortissement admis en déduction**, par catégorie d'actif. C'est la clé
  de la divergence comptable/fiscal : sans lui, pas de tableau de détermination du résultat.
- **Durée minimale d'amortissement des biens en leasing** — indispensable au traitement
  NC 41, dont le volet fiscal est hors du texte de la norme.
- **Délai de forclusion du droit à déduction de la TVA.**

Et deux réserves de sincérité qui méritent d'être connues :

- **CNSS.** Le taux global de 25,75 % (16,57 patronal / 9,18 salarial) est certain, mais
  **aucun décret unique ne le fixe** : c'est un agrégat de trois textes distincts. La
  reconstitution donne 16,07 % côté patronal — **un demi-point n'est rattaché à aucun texte
  identifié**. La part salariale, elle, tombe juste au centième.
- **Convention Tunisie-Allemagne.** Le document en circulation porte une date de signature
  **laissée en blanc** et prévoit l'extinction de la convention de 1975. Statut en vigueur
  non vérifié. Ne pas appliquer ces taux sans confirmation de la DGELF — c'est exactement le
  cas qu'un moteur d'ingestion sans canal d'incertitude aurait ingéré comme « en vigueur ».

## 9. Limites assumées

- `valid_from` est fixé au 1er janvier 2026 parce que c'est la date à laquelle ces valeurs
  sont **constatées** dans les éditions officielles 2026. Ce n'est pas une affirmation sur
  leur entrée en vigueur réelle, souvent bien antérieure. Toute résolution sur une pièce
  antérieure à 2026 échoue — c'est voulu.
- La LF 2026 et toute la doctrine 2026 n'existent qu'en **arabe**. Les éditions françaises
  de la DGELF, avec leurs mentions d'amendement, sont le seul pont fiable — et elles ne
  couvrent que les mesures **codifiées**.
- Le taux d'IS de 15 % n'apparaît pas dans la lecture de l'édition 2026 : les taux relevés
  sont 10, 20, 35 et 40. À confirmer avant toute automatisation du calcul d'IS.
