# Le catalogue des schémas comptables — pourquoi 35 ne suffisait pas

**Statut :** adopté · **Date :** 2026-08-31

---

## Ce qui a changé

| | Avant | Après |
|---|---|---|
| Schémas d'écriture | 35 | **182** |
| Lignes de schéma | 100 | **464** |
| Rôles comptables | 55 | **160** |
| Cycles couverts | implicite | **10, explicites** |

Les 35 premiers schémas couvraient les opérations que le produit traite aujourd'hui —
capture de facture, règlements, paie, TVA, leasing. C'était le noyau opératoire, pas le
catalogue. Je les avais construits à partir des normes lues, donc à partir de ce que
j'avais en tête : c'est une méthode qui produit ce dont on se souvient, pas ce qui existe.

## La méthode, cette fois

Un balayage, pas une intuition. Chaque **cycle** d'un système comptable, croisé avec les
**variantes qui changent l'écriture** :

```
cycles      ventes · achats · trésorerie · paie · immobilisations · stocks ·
            financement et capitaux propres · fiscal · provisions · clôture

variantes   régime de TVA (soumis, exonéré, suspension, export, prorata, non récupérable)
            retenue à la source (opérée / subie)
            devise · avoir · acompte · escompte · effet de commerce
            clôture (charges et produits constatés d'avance, factures à établir,
            factures non parvenues, provisions, écarts de conversion)
```

| Cycle | Schémas | Lignes |
|---|---|---|
| Ventes | 23 | 71 |
| Achats | 28 | 87 |
| Immobilisations | 32 | 75 |
| Financement et capitaux propres | 20 | 48 |
| Paie | 19 | 48 |
| Trésorerie | 18 | 45 |
| Fiscal | 12 | 28 |
| Clôture | 12 | 24 |
| Stocks | 10 | 20 |
| Provisions | 8 | 19 |

## Ce que le balayage a fait apparaître

Des opérations qu'aucune lecture de norme ne m'aurait suggérées, parce qu'elles ne sont
pas dans les normes — elles sont dans la vie d'une PME :

- **Les effets de commerce**, tout leur cycle : acceptation, remise à l'encaissement,
  escompte, impayé. L'escompte n'est pas un encaissement, c'est un financement : l'effet
  reste une créance jusqu'à son échéance.
- **La consignation d'emballages**, qui n'est pas un revenu mais une dette envers le client.
- **L'escompte de règlement**, accordé comme obtenu : une charge et un produit **financiers**,
  jamais une réduction du revenu ou du coût.
- **La TVA autoliquidée** sur une facture de prestataire non résident, collectée et déduite
  dans la même écriture.
- **Le prorata de déduction**, qui répartit la TVA entre le déductible et le coût.
- **Les trois régimes d'écart de conversion** — règlement, clôture court terme, clôture long
  terme — dont le troisième est la divergence assumée avec IAS 21.
- **Le cycle complet des actions propres** : rachat, annulation avec sa cascade
  d'imputation, revente, et le dividende qui leur revient et qui va en résultats reportés.
- **Le fonds social** : le prêt qui laisse la réserve intacte, les intérêts qui **augmentent
  la réserve** au lieu d'être un produit, l'aide non remboursable qui la diminue au lieu
  d'être une charge de personnel.

## Ce que le chargement a corrigé

Deux défauts qu'aucune relecture n'aurait attrapés, et que la base a refusés :

1. Un **type mal cadré** dans le seed du plan comptable, qui faisait échouer le tout premier
   chargement.
2. Le compte **472 « Produits constatés d'avance » portait un sens débiteur** dans le seed
   généré. C'est un passif. La règle de dérivation par préfixe rangeait toute la série 47
   à l'actif ; elle a été corrigée à la main sur ce compte.
3. Un schéma **déséquilibré** — la sous-activité, écrite à une seule ligne. Elle est
   maintenant écrite correctement : le stock n'est valorisé qu'à hauteur des frais fixes
   absorbés, et la fraction non absorbée reste une charge sans contrepartie de stock.

## Ce qui reste vrai

Aucun numéro de compte dans un schéma. Aucun taux, aucun montant, aucun seuil. Les 160
rôles ont tous été **validés à l'insertion par la contrainte de classe** : les 160 liaisons
sont passées devant le déclencheur qui vérifie que le compte existe et que sa classe est
admise par le rôle. Zéro rejet, zéro invariant violé.

## Ce qui n'y est pas encore

Les opérations que le produit ne modélise pas encore : fusion et scission, consolidation,
contrats de concession, instruments financiers dérivés, provisions pour retraite. Et les
schémas propres à des secteurs réglementés — banques, assurances, OPCVM — qui relèvent des
normes sectorielles NC 21 et suivantes, hors du champ d'un produit généraliste.
