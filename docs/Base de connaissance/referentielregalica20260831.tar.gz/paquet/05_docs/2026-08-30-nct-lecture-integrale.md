# Lecture intégrale des Normes Comptables Tunisiennes — règles opposables au produit

**Statut :** adopté
**Date :** 2026-08-30
**Portée :** socle comptable de Regalica Office (plan de comptes, schémas d'écritures, contrôles de cohérence)

---

## 0. Ce qui a été lu, et comment

Quinze normes lues sur **texte primaire**, mot par mot, PDF téléchargés et convertis, chaque citation recoupée sur au moins deux tirages indépendants :

| Norme | Objet | Sources |
|---|---|---|
| NC 01 | Norme comptable générale **+ nomenclature officielle des comptes** | OECT, procomptable (diff code par code : ensembles identiques, 604 comptes) |
| NC 02 | Capitaux propres | OECT |
| NC 03 | Revenus | OECT + exacomaudit |
| NC 04 | Stocks | OECT + exacomaudit |
| NC 05 | Immobilisations corporelles (**version 2022**) | OECT |
| NC 06 | Immobilisations incorporelles | OECT |
| NC 08 | Résultat net et éléments extraordinaires | OECT |
| NC 09 | Contrats de construction | OECT |
| NC 10 | Charges reportées | OECT + procomptable (PDF et HTML) |
| NC 11 | Modifications comptables | OECT |
| NC 12 | Subventions publiques | OECT |
| NC 13 | Charges d'emprunt | OECT |
| NC 14 | Éventualités et événements postérieurs à la clôture | OECT |
| NC 15 | Opérations en monnaies étrangères | OECT |
| NC 41 | Contrats de location (leasing) | **Ministère des Finances** + OECT + comptable-tunisie + exacomaudit (4 copies, identiques § 1-65) |

Normes sectorielles (OPCVM, banques, assurance, micro-crédit, associations sportives) **volontairement exclues** : hors du champ d'un produit comptable généraliste.

Base légale du référentiel : loi n° 96-112 du 30 décembre 1996, art. 7 — « *Les normes comptables sont approuvées par arrêté du ministre des finances.* » Arrêté d'approbation du 31 décembre 1996 pour les normes 1997 ; NC 41 applicable aux exercices ouverts à compter du 1er janvier 2008.

**Convention de lecture appliquée partout :** *[TEXTE]* = citation littérale du texte officiel. *[LECTURE]* = interprétation. Cette frontière est reportée telle quelle dans la base : aucune règle marquée *[LECTURE]* ne peut être présentée à l'utilisateur comme une prescription normative.

---

## 1. Décision structurante — le plan comptable a deux étages, et un seul est officiel

La nomenclature du SCE compte **604 comptes** (plus les 7 classes). C'est un référentiel **fini et vérifiable**. Il ne descend pas partout au niveau dont un logiciel a besoin, et il est **antérieur de douze ans à NC 41**.

Conséquence retenue :

```
is_official = true   -> verbatim NC 01, 611 lignes, jamais modifiable, jamais reformulé
is_official = false  -> subdivision ouverte par Regalica, justifiée, ajustable par l'expert
```

C'est la traduction technique exacte de la règle produit : *Regalica fait son travail par défaut, et si quelque chose doit être paramétré ou changé, cela vient de l'expert.* L'expert ne peut pas casser le socle officiel ; il ne peut agir que sur l'étage d'extension.

### 1.1 Codes que le produit croyait exister et qui n'existent pas

La lecture de la nomenclature primaire a invalidé plusieurs codes utilisés ou recommandés jusqu'ici — y compris des codes que j'avais moi-même recommandés :

| Code | Verdict | Compte officiel qui porte réellement le sens |
|---|---|---|
| **4371** | n'existe pas — 437 n'a **aucune** subdivision officielle | **437** *Autres impôts, taxes et versements assimilés* |
| **4369** | n'existe pas — la série 436 s'arrête à 4368 | **4368** *Taxes sur le chiffre d'affaires à régulariser ou en attente* |
| **4321** | n'existe pas — 432 n'a aucune subdivision | **432** *Etat, impôts et taxes retenus à la source* |
| **445** | n'existe pas — pas de compte « État-TVA » en classe 44 | **436** *Etat - taxes sur le chiffre d'affaires* |
| **241 à 244** | n'existent pas — 24 est donné sans subdivision | **24**, que NC 01 prescrit de ventiler « *dans les mêmes conditions que le compte 22* » |
| **1687** | n'existe pas — 168 = {1681, 1685, 1688} | **1688** *Autres dettes non courantes* (ou subdivision libre) |
| **664, 693, 512** | n'existent pas | 665 / 695 / 532 |
| **1452, 139** | n'existent pas | **1459** et **739** |

Le libellé officiel du **612** est *« Redevances pour utilisation d'immobilisations concédées »* — il vise les **concessions**, pas le crédit-bail. Tout libellé « Redevances de crédit-bail » attaché au 612 dans la base est une invention à supprimer.

### 1.2 Le droit de timbre : la série 436 lui est fermée

Le commentaire officiel de NC 01 est sans ambiguïté :

> *[TEXTE]* « Le compte 436 "Etat - Taxes sur le chiffre d'affaires" reçoit d'une part le montant des taxes collectées pour le compte de l'Etat et, d'autre part, le montant des taxes à récupérer. »
> *[TEXTE]* « Le compte 437 "Autres impôts, taxes et versements assimilés" est crédité du montant de tous les autres impôts et taxes dus par l'entreprise par le débit des comptes de charges intéressés. »

Le droit de timbre n'est pas une taxe sur le chiffre d'affaires. Son seul rattachement officiel est **437**. Regalica ouvre `4371 Etat - droits de timbre collectés` en extension déclarée.

Côté charge, le compte est officiel et existe : **6654 *Droits d'enregistrement et de timbre*** (sous 665).

### 1.3 Retenue à la source : deux comptes, deux sens opposés

Confusion fréquente, tranchée par le texte :

- Retenue **opérée par l'entreprise** sur les sommes qu'elle doit à des tiers → **432**, au crédit.
  *[TEXTE]* « Le compte 432 "Etat - Impôts et taxes retenus à la source" est crédité des retenues effectuées par l'entreprise pour le compte de l'Etat sur des sommes dues à des tiers par le débit de leurs comptes. »
- Retenue **subie par l'entreprise** sur ses propres encaissements → **4341 *Retenue à la source*** (subdivision officielle de 434 *Etat - impôts sur les bénéfices*), au débit : c'est un acompte d'impôt, pas une dette.

Les deux sont officiels. Aucune extension nécessaire.

---

## 2. Décision structurante — un schéma d'écriture ne nomme jamais un compte

Le premier jet des schémas comptables portait des numéros en clair — `4111`, `707`,
`4367`. Ça fonctionne tant que le cabinet garde le plan par défaut. Le jour où un expert
renumérote ses ventes ou éclate son collectif clients, le schéma pointe dans le vide —
et il ne lève pas d'erreur, il produit une écriture fausse. C'était un hardcoding résiduel,
au niveau du tenant.

Le socle a donc trois étages, chacun avec son propriétaire :

| Étage | Contenu | Propriétaire |
|---|---|---|
| **Nomenclature** | 611 lignes verbatim NC 01, `is_official = true` | le législateur |
| **Liaisons** | 55 rôles → 55 comptes, défaut par juridiction, surchargeable par cabinet | l'expert-comptable |
| **Schémas** | 35 écritures-types qui ne connaissent que les rôles | Regalica |

Un cabinet qui renumérote modifie une liaison. Aucun schéma n'est réécrit, aucun contrôle
ne tombe, et un schéma ne peut pas désigner un compte qui n'existe pas.

### La contrainte de classe : rendre la faute impossible plutôt que la détecter

Chaque rôle porte la liste des classes auxquelles il peut être relié. Un rôle de taxe
collectée pour le compte de l'État — `TVA_COLLECTEE`, `TIMBRE_COLLECTE`,
`RETENUE_SOURCE_OPEREE` — n'admet que la classe 4. Relier l'un d'eux à un compte de
produit devient **impossible en base**.

C'est NC 03 §06 rendu structurel plutôt que vérifié :

> *[TEXTE]* « Les sommes encaissées pour le compte de tiers, par exemple les taxes collectées pour le compte de l'Etat […] ne font pas partie des revenus. »

C'est la même intention que la relecture des montants dans le plan de tokens : l'erreur
n'est pas rattrapée à la première facture, elle ne peut pas être saisie.

### Trois conséquences sur les contrôles

Un contrôle formulé sur « le compte 612 » tombe dès la première personnalisation. Formulé
sur les rôles et la classe, il survit à toute renumérotation :

- **location-financement** : aucune ligne ne peut débiter un compte de charge, hors les
  rôles `INTERETS_EMPRUNTS` et `DOTATION_AMORTISSEMENTS` ;
- **revenu** : aucune ligne ne peut débiter un rôle de la famille `produit` en diminution
  d'un revenu déjà comptabilisé pour cause d'impayé ;
- **correction d'erreur fondamentale** : aucune ligne ne peut toucher les familles
  `produit` ou `charge`.

### Un rôle sans liaison est une erreur, jamais un compte deviné

Ordre de résolution : surcharge du tenant → défaut de la juridiction → **erreur explicite
nommant le rôle manquant**. Aucun compte n'est deviné, choisi par défaut, ni créé à la
volée. C'est R8 — un code porte un sens et un seul.


---

## 3. Règles qui décident du traitement d'une facture

### 2.1 Le montant du revenu — NC 03 §06

> *[TEXTE]* « Les revenus doivent être mesurés à la juste valeur des contreparties reçues ou à recevoir […] Les revenus sont nets de remises et réductions commerciales consenties par l'entreprise et les rendus acceptés par elle. **Les sommes encaissées pour le compte de tiers, par exemple les taxes collectées pour le compte de l'Etat** […] **ne font pas partie des revenus.** »

Trois conséquences directes sur le moteur de proposition d'écriture :
1. La TVA collectée **et le droit de timbre collecté** ne touchent jamais un compte de classe 7.
2. Les remises et réductions commerciales figurant sur la facture réduisent la base du revenu ; elles ne créent pas une charge.
3. Un retour accepté réduit le revenu ; un **impayé** ne le réduit pas (voir §25 ci-dessous).

### 2.2 Le moment du revenu — NC 03 §09 et §11

> *[TEXTE] §09* : quatre conditions **cumulatives** — transfert des principaux risques et avantages, mesure fiable du revenu, probabilité des avantages futurs, mesure fiable des coûts.
> *[TEXTE] §11* : le transfert suppose que « *tous les actes importants découlant de la vente ont été exécutés* » et que l'entreprise « *n'exerce plus sur les biens cédés un droit de gestion ou un contrôle effectif* ».

**La facture ne fait pas le revenu.** Une clause de réserve de propriété destinée à garantir le paiement ne bloque pas la constatation (§12 in fine) ; une installation significative restant à faire, si (§12.a).

### 2.3 Interdiction d'annuler un revenu pour impayé — NC 03 §25

> *[TEXTE]* « Si une incertitude relative au recouvrement des contreparties […] prend naissance après la constatation des revenus, on constitue une provision distincte pour en tenir compte, **le montant initialement comptabilisé au titre des revenus n'est pas ajusté.** »

Contrôle à câbler : toute écriture qui débite un compte 70x en contrepartie d'un compte client sur une pièce déjà comptabilisée doit lever une anomalie. Le traitement légal est 416 + 68174/491.

Cette règle rejoint la règle de gouvernance interne **R7** (« une correction est une écriture nouvelle, jamais une modification ») : elle en est le fondement normatif, pas seulement une convention d'architecture.

### 2.4 Le coût d'acquisition d'un achat — NC 04 §12 et §13

> *[TEXTE] §12* : « Le coût d'acquisition des stocks comprend le prix d'achat, les droits de douane à l'importation et **taxes non récupérables par l'entreprise**, ainsi que les frais de transport, d'assurances liés au transport de réception et autres coûts directement liés à l'acquisition. »
> *[TEXTE] §13* : les réductions viennent en déduction, **à l'exception des subventions** portant sur les biens stockés (renvoi à NC 12).

Conséquence pour la lecture de facture : une TVA **non récupérable** n'est pas une charge d'impôt, elle s'incorpore au coût du bien. Le moteur doit donc connaître le régime de déductibilité avant de proposer l'imputation, et non après.

### 2.5 Méthodes de valorisation — NC 04 §25

> *[TEXTE]* « […] doit être déterminé en utilisant la méthode du coût moyen pondéré ou la méthode du premier entré, premier sorti. »

**Rectification d'une affirmation antérieure :** NC 04 ne comporte **aucune interdiction explicite** du LIFO. L'exclusion résulte du caractère fermé de la liste — c'est une lecture, pas une citation. Le produit doit la présenter comme telle.

---

## 4. NC 41 — la règle qui change le plus de choses en Tunisie

Le crédit-bail est massivement utilisé en Tunisie. Le traitement historique — passer la redevance en charge — est **proscrit** dès lors que le contrat est en location-financement.

> *[TEXTE] §22* : « Les paiements minimaux au titre de la location **doivent être ventilés entre la charge financière et l'amortissement du solde de la dette**. »
> *[TEXTE] §26* : « […] **il est donc inapproprié de se contenter de comptabiliser en charges les paiements à effectuer au titre de la location.** »

### 3.1 Énoncé opératoire

Dès qu'un contrat est classé location-financement, **aucun compte de la classe 61** — ni 612, ni 613, ni aucune subdivision « redevances de leasing » — ne reçoit la redevance, ni en totalité ni en fraction. La redevance cesse d'être une charge et devient un désendettement éclaté en trois flux :

| Flux | Compte | Base |
|---|---|---|
| Remboursement du principal | **1686** (ext.) / **505** — compte de bilan, **aucune charge** | redevance HT − intérêts de la période |
| Charge financière | **651** (6511 / 65116) | taux d'intérêt implicite × capital restant dû — taux **actuariel**, pas linéaire (§22) |
| Amortissement du bien | **6811** → **284x** | base = coût comptabilisé au §17 ; durée selon §24-25 |

Entrée du bien à l'actif en **24x** *Immobilisations à statut juridique particulier* — et non en 22x. Le commentaire officiel du compte 24 le dit expressément :

> *[TEXTE] NC 01, cpte 24* : « Ce compte est destiné à enregistrer les immobilisations obtenues ou contrôlées par l'entreprise sous un régime juridique particulier. Ce compte est ventilé dans les mêmes conditions que le compte 22. **Il implique, pour les entreprises concernées, la constatation dans les passifs des obligations correspondantes.** »

### 3.2 Trois précisions qui évitent des erreurs

1. **NC 41 ne cite jamais la loi n° 94-89 sur le leasing.** Le seul rattachement est le §1 al. 2 (« *Les contrats de location financement couvrent, entre autres, les contrats de leasing* »), qui **n'est pas une présomption irréfragable** : chaque contrat doit passer le test des §6-16.
2. **Aucun seuil chiffré dans NC 41** — ni 75 %, ni 90 %. La norme n'emploie que « la majeure partie » (§9.c) et « la quasi-totalité » (§9.d). Toute grille chiffrée est une convention d'entreprise ; Regalica ne peut pas la présenter comme normative.
3. **Loyer conditionnel** (indexé TMM) : charge de la période, **hors** dette initiale.

### 3.3 Contrôle bloquant

Tout débit d'un compte 612 ou 613 rattaché à un contrat marqué *location-financement* lève une anomalie bloquante.

---

## 5. Règles opératoires par norme — synthèse pour le moteur

| Norme | Règle qui décide | Compte(s) |
|---|---|---|
| NC 03 §06 | revenu net de remises, **hors taxes collectées pour l'État** | 70x vs 4367/4371 |
| NC 03 §15 | hors régie, un acompte reçu **ne mesure pas** l'avancement | 4191 reste au passif |
| NC 03 §25 | impayé → provision, **jamais** annulation du revenu | 416 / 68174 / 491 |
| NC 04 §12 | TVA **non récupérable** → incorporée au coût, pas en charge d'impôt | 60x / 6652 |
| NC 04 §17 | sous-activité : quote-part de frais fixes non imputée = charge de la période | 6x |
| NC 04 §23 | charges financières incorporables uniquement si cycle **> 12 mois** | 65x |
| NC 04 §33 | inventaire physique **au moins une fois par an** | 3x |
| NC 09 §07 | coûts pré-contractuels passés en charge : **capitalisation définitivement perdue** | règle de non-retour |
| NC 09 §25-26 | perte à terminaison provisionnée **même chantier non démarré**, sans compensation entre contrats | 6815 / 1513 |
| NC 10 §04 | liste **fermée** de trois catégories ; traitement **résiduel et subsidiaire** | 271 / 272 / 273 |
| NC 10 §16 | **frais internes non activables** en action de développement | seuls les frais externes identifiés |
| NC 10 §13 | recettes de pré-exploitation → **déduction de l'actif**, aucun produit | 271 au crédit |
| NC 10 (NC 01 cpte 27) | la résorption **crédite directement le 27** : pas de compte 28 pour les charges reportées → valeur brute et cumul à tenir hors bilan pour la note du §30 | 6812 / 27 |
| NC 11 §17 | modification comptable / erreur fondamentale → **128**, jamais le résultat | 128 |
| NC 12 §03 | avantages fiscaux **sans transfert de ressources** (exonérations, taux réduits, prise en charge CNSS) → **aucune écriture**, note seulement | — |
| NC 12 §07 | champ **plus large qu'IAS 20** : couvre aussi les subventions **privées** | 145 / 74 |
| NC 12 §14 | reprise **strictement proportionnelle** à l'amortissement du bien financé | 1459 / 739 |
| NC 13 §07 | capitalisation des charges d'emprunt **obligatoire**, non optionnelle, quand les conditions sont réunies | — |
| NC 14 | événements postérieurs : **ajustement** vs **simple mention** — deux régimes disjoints | — |
| NC 15 §16-18 | écarts de change sur éléments monétaires **à long terme** : **différés et amortis** via un compte de bilan (**écart avec IAS 21**) | 185 |
| NC 02 §09 | actions propres : **119**, soustractif des capitaux propres, **jamais à l'actif** | 119 |
| NC 02 §12 | gains/pertes sur actions propres **hors résultat** | compléments d'apport |
| NC 02 §17 | intérêts sur prêts du fonds social → **1181**, pas un compte 75x | 1181 |

### 4.1 Ce que NC 02 ne contient pas

NC 02 est bien plus étroite que son titre. Elle ne contient **ni** le taux ni le plafond de la réserve légale, **ni** la mécanique d'affectation du résultat, **ni** un état de variation des capitaux propres. Rattachements corrects :

- Réserve légale → **Code des sociétés commerciales, art. 287** : *[TEXTE]* « une fraction égale à **5 %** du bénéfice […] Ce prélèvement cesse d'être obligatoire lorsque la réserve légale atteint **le dixième du capital social** ». Compte **111**.
- Affectation du résultat → **NC 01, commentaire du compte 13** : « Le compte 13 est soldé après décision d'affectation du résultat. Dans les sociétés, les montants non distribués et non affectés à un compte de réserves sont virés au compte 12 […] Dans les entreprises individuelles, le solde du compte 13 est viré au compte 108 ».
- Mouvements des capitaux propres → **NC 01 §83** : une **note de rapprochement** poste par poste, ouverture → clôture. **Pas un état primaire** : les états financiers NCT en comportent **quatre**, pas cinq — écart net avec IAS 1 §106.

Ces trois points alimentent directement le chantier *exercices / clôture / à-nouveaux*.

---

## 6. Ce que cette lecture impose au produit

1. **Remplacer** les deux fichiers de plan comptable écrits de mémoire par le seed généré
   depuis la nomenclature primaire — 611 lignes, libellés verbatim.
2. **Ajouter** `is_official` et `source_ref` sur `ref.accounts` : sans eux, la frontière
   socle/extension n'est pas exprimable et l'expert ne sait pas ce qu'il a le droit de
   modifier.
3. **Introduire la couche de rôles** — `ref.account_roles`, `ref.role_bindings`,
   `tenant.role_bindings` — avec la contrainte de classe appliquée par la base, et non par
   le code applicatif.
4. **Réécrire les schémas** pour qu'ils ne portent plus aucun numéro de compte : une ligne
   de schéma référence un rôle, avec clé étrangère.
5. **Réimputer** le droit de timbre collecté via le rôle `TIMBRE_COLLECTE` relié à `4371`
   (extension déclarée sous 437), par écritures nouvelles au statut `proposee` — jamais par
   migration de données, conformément à R7 et à NC 03 §25.
6. **Séparer** les deux retenues à la source : `RETENUE_SOURCE_OPEREE` → 432 au crédit,
   `RETENUE_SOURCE_SUBIE` → 4341 au débit.
7. **Corriger** le libellé du 612 partout où il porte « Redevances de crédit-bail ».
8. **Marquer** chaque règle stockée avec son statut : `texte` citable, `lecture`
   interprétative. Une règle `lecture` ne peut pas être affichée comme une prescription.

## 7. Limites assumées

- Le **traitement fiscal** corrélatif de NC 41 (déductibilité de l'amortissement et des intérêts en lieu et place de la redevance) est **hors du texte de la norme** : à valider sur le Code de l'IRPP/IS avant toute automatisation.
- Les subdivisions `1686`, `1881`, `241-248`, `2841-2848`, `4371-4373` sont des **extensions Regalica**, cohérentes avec les commentaires de NC 01 mais **non prescrites** par un texte primaire.
- Les écritures du **bailleur** en location-financement relèvent en outre du référentiel bancaire (NC 21 et suivantes), non lu.
- Le sens usuel (`normal_side`) et le caractère collectif (`is_collective`) ne figurent dans **aucun** texte officiel : ce sont des conventions d'ergonomie, paramétrables, jamais opposables.
