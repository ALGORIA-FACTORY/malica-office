# Référentiel Regalica Office — paquet complet

Tout ce qui a été établi au cours de cette session, dans l'ordre où cela se charge.
**Rien ici ne dépend de ma mémoire ni de cette conversation.**

## Reconstruire

```bash
./reconstruire.sh "postgres://…"     # charge tout, dans l'ordre, puis vérifie
psql "postgres://…" -f garanties.sql # exécute les 10 garanties du produit
```

`dump_referentiel.sql` est un instantané restaurable de la base telle qu'elle a été
vérifiée, si vous préférez restaurer plutôt que rejouer.

Chaque fichier est **idempotent** : le rejeu ne produit aucun doublon.

## Ce que ça contient

| | |
|---|---|
| Comptes officiels, verbatim NC 01 | **611** |
| Extensions Regalica, chacune justifiée | **15** |
| Rôles comptables | **160** |
| Liaisons rôle → compte (Tunisie) | **160** |
| Schémas d'écriture | **182** (464 lignes), 10 cycles |
| Contrôles normatifs | **5** |
| Paramètres fiscaux, chacun avec son article | **454** |
| Obligations déclaratives | **43** |
| Documents en file d'ingestion | **788** |
| Documents ingérés | **786 / 788** — 21 973 pages |
| Références juridiques extraites | **23 631** |
| Occurrences d'articles découpées, chacune empreinte | **12 504** |
| Identités d'articles · versions distinctes | **3 110 · 4 902** |
| OCR bilingue français-arabe | en cours sur 140 scans |

## Arborescence

```
01_socle/       bootstrap (hors dépôt) + migration is_official / source_ref
02_comptable/   plan officiel, extensions, rôles, liaisons, schémas  (+ les 3 JSON sources)
03_fiscal/      schéma, 454 paramètres, 43 obligations  (+ le CSV d'audit des conversions)
04_corpus/      file d'ingestion des 788 documents  (+ les 4 inventaires vérifiés)
05_docs/        les trois notes de décision
06_prompts/     les trois prompts : comptable, fiscal, ingestion du corpus
```

## Le seul point à ajuster dans votre dépôt

`00_bootstrap.sql` **ne doit pas être joué** : `ref.jurisdiction_packs` et `ref.accounts`
existent déjà chez vous. Il n'est là que pour permettre de vérifier les seeds hors dépôt.

Un seul détail de typage peut différer : les seeds du plan comptable supposent
`account_class` de type **entier**. Si votre colonne est de type texte, retirez le `::int` —
c'est signalé en tête des deux fichiers, et c'est la seule ligne à toucher.

## Les dix garanties, vérifiées

Chacune **doit échouer**. Un test qui passe est une régression.

| | Ce qui est interdit | Par quoi |
|---|---|---|
| G1 | Modifier le libellé d'un compte officiel NC 01 | trigger `proteger_comptes_officiels` |
| G2 | Relier la TVA collectée à un compte de produit | contrainte de classe du rôle |
| G3 | Un cabinet reliant le timbre collecté à une charge | même contrainte, sur la table tenant |
| G4 | Relier un rôle à un compte inexistant | même trigger |
| G5 | Un paramètre fiscal confirmé sans article | `fiscal_param_citation` |
| G6 | Deux versions d'un paramètre qui se chevauchent | exclusion GiST sur `daterange` |
| G7 | Résoudre un paramètre inexistant | erreur nommant le paramètre |
| G8 | Résoudre une pièce de 2024 avec les valeurs 2026 | erreur, jamais d'extrapolation |
| G9 | Calculer avec un paramètre non établi | erreur explicite |
| G10 | Calculer sur un barème incomplet | erreur explicite |

## Ce qui reste ouvert, et qui compte

- **13 paramètres non établis**, en base sans valeur pour que l'absence se voie. Les deux
  qui bloquent : les **taux maximaux d'amortissement admis en déduction** — sans eux, pas
  de tableau de détermination du résultat fiscal — et la **Contribution Sociale de Solidarité**.
- **Un demi-point patronal CNSS orphelin.** Le taux global de 25,75 % est certain, mais la
  reconstitution à partir des textes donne 16,07 % côté employeur là où la CNSS publie 16,57 %.
- **La convention Tunisie-Allemagne** : le document en circulation porte une date de
  signature laissée en blanc. Ne pas appliquer ses taux sans confirmation de la DGELF.
- **Le taux d'IS de 15 %** n'apparaît pas dans l'édition 2026 : les taux relevés sont
  10, 20, 35 et 40. À confirmer avant d'automatiser le calcul d'IS.
- **788 documents à ingérer**, dont 135 prioritaires. Aucun n'a été lu article par article :
  seuls les cinq corpus consolidés 2026 l'ont été, pour en extraire les 454 paramètres.
- **Le corpus bascule vers l'arabe** : 17 notes communes sur 17 en 2026, et la LF 2026.
  L'OCR et la segmentation doivent être bilingues dès le premier jour.

## Ce qui n'est pas ici

Le chantier comptable proprement dit — exercices et à-nouveaux, table des tiers, devises,
lettrage — et les 17 index `tenant_id` manquants relevés lors de l'audit de la base.
Ils sont décrits dans les notes de décision, pas encore outillés.
