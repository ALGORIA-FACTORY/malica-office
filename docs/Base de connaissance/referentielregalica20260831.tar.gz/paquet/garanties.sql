-- Regalica Office — les garanties du produit, vérifiées en base.
-- Chaque insertion ci-dessous DOIT échouer. Un test qui passe est une régression.
\set ON_ERROR_STOP off
\echo '=== G1  modifier le libellé d''un compte officiel NC 01'
update ref.accounts set label = 'Redevances de crédit-bail' where account_code = '612';
\echo '=== G2  relier la TVA collectée à un compte de produit'
insert into ref.role_bindings (pack_version_id, role_code, account_code)
  select id,'TVA_COLLECTEE','707' from ref.jurisdiction_packs where jurisdiction='TN'
  on conflict (pack_version_id, role_code) do update set account_code = excluded.account_code;
\echo '=== G3  un cabinet relie le timbre collecté à un compte de charge'
insert into tenant_role_bindings (tenant_id, portee, portee_id, role_code, account_code)
  values (gen_random_uuid(),'cabinet',gen_random_uuid(),'TIMBRE_COLLECTE','6654');
\echo '=== G4  relier un rôle à un compte qui n''existe pas'
insert into tenant_role_bindings (tenant_id, portee, portee_id, role_code, account_code)
  values (gen_random_uuid(),'dossier',gen_random_uuid(),'CLIENT_COLLECTIF','99999');
\echo '=== G5  un paramètre fiscal confirmé sans article'
insert into ref.fiscal_parameters (jurisdiction,code,libelle,forme,echelle,valeur_num,valeur_brute,corpus,autorite,confiance,valid_from)
  values ('TN','G5','Taux inventé','taux','ratio',0.19,'19%','CTVA','texte','confirme',date '2026-01-01');
\echo '=== G6  deux versions d''un paramètre qui se chevauchent'
insert into ref.fiscal_parameters (jurisdiction,code,libelle,forme,echelle,valeur_num,valeur_brute,corpus,article,citation,autorite,confiance,valid_from)
  values ('TN','tva_taux_normal','Doublon','taux','ratio',0.25,'25%','CTVA','art. 7','x','texte','confirme',date '2026-06-01');
\set ON_ERROR_STOP on
\echo ''
\echo '=== G7 à G9  la résolution refuse plutôt que de deviner'
do $$ begin perform ref.parametre_fiscal('TN','NEXISTE_PAS',date '2026-03-15');
      exception when others then raise notice 'G7 %', SQLERRM; end $$;
do $$ begin perform ref.parametre_fiscal('TN','tva_taux_normal',date '2024-03-15');
      exception when others then raise notice 'G8 %', SQLERRM; end $$;
do $$ begin perform ref.parametre_fiscal('TN','CSS_TAUX',date '2026-03-15');
      exception when others then raise notice 'G9 %', SQLERRM; end $$;
\echo ''
\echo '=== G10 un barème incomplet ne calcule pas'
do $$ begin perform ref.appliquer_bareme('TN','FORFAIT_BAREME',date '2026-03-15',50000);
      exception when others then raise notice 'G10 %', SQLERRM; end $$;
\echo ''
\echo '=== CONTRÔLES DE JUSTESSE ==='
select 'libellé officiel du 612' q, label r from ref.accounts where account_code='612'
union all select 'timbre collecté -> compte', b.account_code from ref.role_bindings b where b.role_code='TIMBRE_COLLECTE'
union all select 'TVA collectée -> compte', b.account_code from ref.role_bindings b where b.role_code='TVA_COLLECTEE'
union all select 'droit de timbre sur facture', valeur_num::text from ref.fiscal_parameters where code='TIMBRE_FACTURE'
union all select 'TCL taux normal', valeur_num::text from ref.fiscal_parameters where code='TCL_TAUX_NORMAL'
union all select 'IRPP sur 12 000 DT', ref.appliquer_bareme('TN','IRPP_BAREME',date '2026-03-15',12000)::text
union all select 'schéma citant un contrôle inconnu', count(*)::text from ref.entry_templates t
   where t.controle is not null and not exists (select 1 from ref.entry_controls c where c.code=t.controle);
