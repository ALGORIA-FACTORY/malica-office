-- Regalica Office — garanties de la couche fiscale.
-- Ce ne sont pas des tests de régression : ce sont les promesses du produit.
-- Les trois premiers doivent ÉCHOUER. Les trois suivants doivent REFUSER.
\set ON_ERROR_STOP off
\echo '=== T1  paramètre confirmé sans article -> refus attendu'
insert into ref.fiscal_parameters (jurisdiction,code,libelle,forme,echelle,valeur_num,valeur_brute,corpus,autorite,confiance,valid_from)
values ('TN','T1','Taux inventé','taux','ratio',0.19,'19%','CTVA','texte','confirme',date '2026-01-01');
\echo '=== T2  deux versions qui se chevauchent -> refus attendu'
insert into ref.fiscal_parameters (jurisdiction,code,libelle,forme,echelle,valeur_num,valeur_brute,corpus,article,citation,autorite,confiance,valid_from)
values ('TN','tva_taux_normal','Doublon','taux','ratio',0.25,'25%','CTVA','art. 7','x','texte','confirme',date '2026-06-01');
\echo '=== T3  non_trouve porteur d une valeur -> refus attendu'
insert into ref.fiscal_parameters (jurisdiction,code,libelle,forme,echelle,valeur_num,valeur_brute,corpus,autorite,confiance,valid_from)
values ('TN','T3','Valeur devinée','taux','ratio',0.10,'10%','CNSS','texte','non_trouve',date '2026-01-01');
\set ON_ERROR_STOP on
\echo ''
\echo '=== T4/T5/T6  la résolution refuse plutôt que de deviner'
do $$ begin perform ref.parametre_fiscal('TN','NEXISTE_PAS',date '2026-03-15');
      exception when others then raise notice 'T4 refus : %', SQLERRM; end $$;
do $$ begin perform ref.parametre_fiscal('TN','tva_taux_normal',date '2024-03-15');
      exception when others then raise notice 'T5 refus : %', SQLERRM; end $$;
do $$ begin perform ref.parametre_fiscal('TN','CSS_TAUX',date '2026-03-15');
      exception when others then raise notice 'T6 refus : %', SQLERRM; end $$;
\echo ''
\echo '=== T7  un barème incomplet ne calcule pas'
do $$ begin perform ref.appliquer_bareme('TN','FORFAIT_BAREME',date '2026-03-15',50000);
      exception when others then raise notice 'T7 refus : %', SQLERRM; end $$;
\echo ''
\echo '=== T8  les valeurs les plus piégeuses'
select code, valeur_num, valeur_brute, echelle from ref.fiscal_parameters
where code in ('tva_taux_normal','TIMBRE_FACTURE','TCL_TAUX_NORMAL','IS_MIN_IMPOT_TAUX_NORMAL',
               'DONS_PLAFOND_GENERAL','CNSS_RSNA_TAUX_PATRONAL') order by code;
\echo ''
\echo '=== T9  barème IRPP : contrôle arithmétique à la main'
select 12000 as revenu, ref.appliquer_bareme('TN','IRPP_BAREME',date '2026-03-15',12000) as calcule,
       5000*0.15 + 2000*0.25 as attendu;
\echo ''
\echo '=== T10 invariants'
select 'paramètres sans citation' as invariant, count(*) as doit_etre_zero from ref.fiscal_parameters
  where valeur_num is not null and (article is null or citation is null)
union all select 'non_trouve avec valeur', count(*) from ref.fiscal_parameters
  where confiance='non_trouve' and valeur_num is not null;
