# Chantier — Socle comptable NCT : plan officiel, rôles comptables, schémas d'écritures

Six fichiers accompagnent ce prompt. Ils sortent d'une lecture mot par mot de quinze normes
comptables tunisiennes sur texte primaire (OECT, Ministère des Finances, procomptable),
y compris la **nomenclature officielle annexée à NC 01** — 604 comptes, diffée code par code
entre deux tirages indépendants.

```
docs/decisions/2026-08-30-nct-lecture-integrale.md   ADR — règles opposables au produit
db/seed/plan_comptable_tn_officiel.sql               611 lignes verbatim NC 01
db/seed/plan_comptable_tn_extensions.sql             15 extensions Regalica justifiées
db/seed/roles_comptables.json                        55 rôles comptables + contraintes de classe
db/seed/liaisons_roles_tn.json                       55 liaisons rôle → compte, défaut TN
db/seed/schemas_comptables_tn.json                   35 schémas d'écritures + 5 contrôles
```

Lis l'ADR en premier : il porte les citations qui fondent chaque décision ci-dessous.

---

## L'idée directrice — trois étages, pas deux

Un schéma d'écriture ne désigne **jamais** un numéro de compte. Il désigne un **rôle**.
Le rôle est relié à un compte par une **liaison**, que l'expert peut changer pour son
cabinet. Trois étages, chacun avec son propriétaire :

```
NOMENCLATURE   611 lignes verbatim NC 01           propriétaire : le législateur
               is_official = true, jamais modifiées, coquilles officielles comprises

LIAISONS       55 rôles → 55 comptes               propriétaire : l'expert-comptable
               défaut Regalica par juridiction, surchargeable par tenant

SCHÉMAS        35 écritures-types                  propriétaire : Regalica
               ne connaissent que les rôles, jamais un numéro
```

Un cabinet qui renumérote son plan modifie une liaison. Aucun schéma n'est réécrit,
aucun contrôle ne tombe, et un schéma ne peut pas pointer dans le vide.

C'est ce qui manquait à la version précédente de ces fichiers, où les schémas portaient
des numéros en clair : ça marchait tant que le cabinet gardait le plan par défaut, et
produisait des écritures fausses — **sans message d'erreur** — dès la première
personnalisation.

## Le contrôle le plus important est une contrainte, pas une vérification

Chaque rôle porte `classes_admises`. Un rôle de taxe collectée pour le compte de l'État
— `TVA_COLLECTEE`, `TIMBRE_COLLECTE`, `RETENUE_SOURCE_OPEREE` — n'admet que la classe 4.
Relier l'un d'eux à un compte de produit devient **impossible en base**, au lieu d'être
une faute rattrapée à la première facture.

C'est NC 03 §06 rendu structurel : « *Les sommes encaissées pour le compte de tiers, par
exemple les taxes collectées pour le compte de l'Etat […] ne font pas partie des revenus.* »
Même intention que la relecture des montants dans le plan de tokens : rendre la faute
impossible plutôt que la détecter.

---

## Lot 1 — Migration du socle

```sql
alter table ref.accounts
  add column if not exists is_official boolean not null default false,
  add column if not exists source_ref  text;

comment on column ref.accounts.is_official is
  'true = verbatim NC 01 (nomenclature officielle SCE), non modifiable. '
  'false = subdivision ouverte par Regalica, ajustable par l''expert.';
```

Ajoute le mécanisme qui empêche le chemin de paramétrage de modifier un compte
`is_official = true`. Trigger, politique RLS, colonne générée — choisis le plus simple
qui tienne, et explique-le en une phrase dans la migration.

## Lot 2 — Remplacer les deux seeds écrits de mémoire

`db/seed/plan_comptable_tn_1a4.sql` et `plan_comptable_tn_5a7.sql` (264 comptes) ont été
rédigés sans texte primaire. La nomenclature officielle a montré qu'ils contiennent des
codes **qui n'existent pas** : `4371`, `4369`, `4321`, `445`, `241`-`244`, `1687`, `664`,
`693`, `512`, `1452`, `139`. Et le libellé du `612` y est faux : le libellé officiel est
« Redevances pour utilisation d'immobilisations concédées » — ce compte vise les
**concessions**, pas le crédit-bail.

1. Supprime les deux fichiers.
2. Charge `plan_comptable_tn_officiel.sql` puis `plan_comptable_tn_extensions.sql`.
3. Si des comptes des anciens seeds sont déjà en base, **ne les efface pas en aveugle** :
   liste d'abord ceux qui portent des écritures et rapporte-les. Un compte inexistant qui
   porte des écritures est un incident comptable, pas une ligne de seed à supprimer.

Contrôle de sortie : `select count(*) from ref.accounts where is_official` = **611**.

## Lot 3 — Rôles et liaisons

Trois tables, et la fonction de résolution qui les relie.

```
ref.account_roles          code, libelle, famille, classes_admises, resolution, auxiliaire, note
ref.role_bindings          pack_version_id, role_code, account_code, justification
tenant.role_bindings       tenant_id, role_code, account_code   -- surcharge de l'expert
```

Exigences non négociables :

1. **Contrainte de classe appliquée à l'insertion et à la mise à jour**, sur les deux
   tables de liaison. Un test doit prouver qu'une liaison `TVA_COLLECTEE` → compte de
   classe 7 est rejetée par la base, pas par le code applicatif.
2. **Une liaison vers un compte absent de `ref.accounts` échoue au chargement**, jamais à
   la première facture.
3. **Ordre de résolution** : surcharge du tenant → défaut de la juridiction → **erreur
   explicite nommant le rôle manquant**. Aucun compte n'est jamais deviné, choisi par
   défaut, ni créé à la volée. C'est le contrôle `LIAISON_OBLIGATOIRE`.
4. `resolution: "par_nature"` signifie que la liaison donne un compte de regroupement et
   un périmètre : le socle résout la feuille selon la nature de la ligne de facture, en
   restant dans le périmètre. `resolution: "fixe"` interdit cette résolution.

Charge `roles_comptables.json` puis `liaisons_roles_tn.json`.
Contrôle de sortie : **55 rôles, 55 liaisons, zéro rôle sans liaison**.

## Lot 4 — Table des schémas comptables

`propose-ecriture.ts` code en dur les journaux `ACH` / `VEN` et une poignée d'imputations.
C'est un manquement à R4 et à « zéro hardcoding ».

Crée `ref.journals`, `ref.entry_templates`, `ref.entry_template_lines`, puis charge
`schemas_comptables_tn.json`. Le JSON est délibérément neutre quant au schéma SQL : la
forme des tables est ton choix. Trois exigences :

1. **Aucun taux, aucun montant, aucun seuil.** Les lignes référencent des *grandeurs*
   (`montant_ht`, `tva`, `timbre`, `rs`…) que le socle calcule depuis
   `ref.fiscal_parameters` à la date de la pièce. Un taux de TVA dans un seed est
   exactement le défaut que ce chantier corrige.
2. **Aucun numéro de compte.** Une ligne de schéma porte un `role_code`, avec clé
   étrangère vers `ref.account_roles`. Ajoute un test qui échoue si une colonne de
   `entry_template_lines` peut contenir un code de compte.
3. Chaque schéma conserve **sa base normative** (`norme`, `paragraphes`, `statut`,
   `regle`). `statut` vaut `texte` ou `lecture` : une règle marquée `lecture` ne peut
   jamais être présentée à l'utilisateur comme une prescription normative — c'est R2.

## Lot 5 — Les cinq contrôles

Ils sont décrits dans la section `controles` du JSON, avec leur fondement et le message
à afficher. Trois remarques :

| Contrôle | Où il s'applique |
|---|---|
| `TAXE_COLLECTEE_JAMAIS_UN_REVENU` | **à la liaison**, pas à la comptabilisation — c'est la contrainte du lot 3 |
| `LOCATION_FINANCEMENT_SANS_CHARGE_DE_LOYER` | à la comptabilisation, formulé sur les **rôles et la classe**, jamais sur « le compte 612 » |
| `REVENU_NON_ANNULABLE` | à la comptabilisation, sur la **famille de rôle** `produit` |

Le message d'erreur cite la norme et le paragraphe. Un comptable qui voit un blocage doit
pouvoir vérifier lui-même que le logiciel a raison.

## Lot 6 — Le droit de timbre et les deux retenues à la source

Le rôle `TIMBRE_COLLECTE` est relié à `4371`, extension déclarée sous `437` — le seul
rattachement officiel, la série 436 étant réservée aux taxes sur le chiffre d'affaires.

Pour les pièces déjà comptabilisées sur un compte de la série 436 : **aucune migration de
données**. Génère des écritures de reclassement au statut `proposee`, conformément à R7 et
à NC 03 §25. L'expert valide, ou pas.

Et sépare les deux retenues, que le produit confondait :

| Situation | Rôle | Sens | Nature |
|---|---|---|---|
| retenue **opérée** sur les fournisseurs | `RETENUE_SOURCE_OPEREE` → `432` | crédit | dette envers l'État |
| retenue **subie** sur les encaissements | `RETENUE_SOURCE_SUBIE` → `4341` | débit | acompte d'impôt sur les bénéfices |

Les deux comptes sont officiels et sans subdivision. Rien à créer, tout à corriger.

## Lot 7 — Ce que le chantier débloque ensuite

Ne le fais pas maintenant. NC 02 et NC 11 ont livré les règles qui manquaient au chantier
*exercices / clôture / à-nouveaux* :

- réserve légale : **5 % du bénéfice distribuable, plafond 1/10 du capital** — source
  **CSC art. 287**, NC 02 étant muette sur les chiffres ;
- affectation du résultat : NC 01, commentaire du compte 13 — sociétés → `12`, entreprise
  individuelle → `108` ;
- mouvements des capitaux propres : NC 01 §83 exige une **note de rapprochement**, pas un
  état primaire. Les états financiers tunisiens en comportent **quatre**, pas cinq.

---

## Règles de travail

- Zéro hardcoding, zéro stub, zéro placeholder, zéro doublon. Si un lot te conduit à en
  introduire un, arrête-toi et dis-le.
- Les libellés `is_official = true` sont **verbatim** : ni reformulation, ni correction
  d'orthographe, ni harmonisation de casse. Les coquilles de la source officielle sont
  conservées, et c'est volontaire.
- Chaque migration idempotente et rejouable.
- Ne réponds pas « fait ». Réponds avec les comptages — `is_official` = 611, extensions
  = 15, rôles = 55, liaisons = 55, schémas = 35, contrôles = 5, tests verts — et la liste
  de ce que tu n'as pas touché.
