# Chantier 2 — La couche fiscale

Ce chantier est **indépendant** du chantier comptable et peut être mené en parallèle.
C'est le test de la séparation : si l'un doit attendre l'autre, la séparation est décorative.

Fichiers fournis :

```
docs/decisions/2026-08-30-couche-fiscale.md        ADR — architecture et état des lieux
db/fiscal/ddl_fiscal.sql                           schéma + fonctions de résolution
db/seed/parametres_fiscaux_tn.sql                  454 paramètres, chacun avec son article
db/seed/obligations_fiscales_tn.sql                43 obligations déclaratives
prompts/INGESTION_CORPUS_JURIDIQUE.md              prompt de segmentation du corpus
```

Le DDL et les deux seeds ont été **chargés et testés sur PostgreSQL 16**. Les contraintes ont
été vérifiées comme mordant réellement. Ne les affaiblis pas pour faire passer une donnée :
si une ligne est refusée, c'est la ligne qui est fausse.

---

## Lot 1 — Le schéma et les seeds

Applique `ddl_fiscal.sql`, puis les deux seeds. `btree_gist` est requis pour la contrainte
d'exclusion temporelle.

Contrôles de sortie attendus :

```
select count(*) from ref.fiscal_parameters;                          -- 454
select count(*) from ref.fiscal_obligations;                         -- 43
select count(*) from ref.fiscal_scale_brackets;                      --   8  (barème IRPP)
select count(*) from ref.fiscal_parameters
  where valeur_num is not null and (article is null or citation is null);  -- 0
```

## Lot 2 — Trois tests qui doivent échouer

Ce ne sont pas des tests de régression, ce sont les garanties du produit. Écris-les, et
vérifie qu'ils **échouent bien** :

1. Insérer un paramètre `confiance = 'confirme'` **sans article** → refusé par
   `fiscal_param_citation`.
2. Insérer une seconde version d'un paramètre existant dont la période **chevauche** la
   première → refusé par `fiscal_param_sans_chevauchement`.
3. Insérer un paramètre `confiance = 'non_trouve'` **porteur d'une valeur** → refusé par
   `fiscal_param_non_trouve_sans_valeur`.

Puis trois refus applicatifs, via `ref.parametre_fiscal` :

4. Un paramètre inexistant → erreur nommant le code.
5. Un paramètre hors période (une pièce de 2024) → erreur, **jamais** la valeur 2026.
6. Un paramètre `non_trouve`, par exemple `CSS_TAUX` → erreur disant qu'il n'est pas établi
   sur source officielle.

## Lot 3 — Le contrat avec la couche comptable

C'est le point d'articulation des deux chantiers.

Les 35 schémas comptables référencent des **grandeurs** — `montant_ht`, `tva`, `timbre`,
`rs`, `tva_nd`. Écris le résolveur qui les calcule, et **uniquement** depuis
`ref.parametre_fiscal`. Trois interdits :

- Aucune constante fiscale en TypeScript. Pas même « en attendant ».
- Aucun repli sur une valeur par défaut quand un paramètre manque : l'erreur remonte.
- La résolution se fait sur la **date de la pièce**, jamais `now()`.

Signature attendue, à respecter même si l'implémentation est partielle :

```
resoudreGrandeurs(piece: { date, jurisdiction, regime, lignes }) : Grandeurs
```

Si un paramètre manque, la fonction lève une erreur qui **nomme le paramètre**. C'est le
jumeau exact de « le rôle X n'est relié à aucun compte » du chantier comptable.

## Lot 4 — Le régime du dossier, en périodes

Le régime conditionne chaque écriture d'un dossier, et il **change** : une société devient
exportatrice, franchit un seuil, opte pour la TVA. Si tu le stockes en colonne sur la fiche
client, le jour où il change, toutes les écritures passées se réinterprètent.

```
tenant.dossier_regimes(dossier_id, valid_from, valid_to, ...)
```

Champs minimaux pour la Tunisie : assujettissement TVA (total / partiel avec prorata / non
assujetti), réel ou forfaitaire, exportateur totalement ou partiellement, régime suspensif,
forme juridique — elle commande la réserve légale, CSC art. 287 — et la **date de clôture de
l'exercice**, qui n'est pas toujours le 31 décembre.

Deux règles :

- Le régime se déclare à l'**ouverture du dossier par le cabinet**, jamais dans l'onboarding
  de la PME : un dirigeant ne sait pas s'il est assujetti partiel, il répondra quand même,
  et le dossier sera faux pour des années.
- Pour une PME sans cabinet : régime par défaut le plus courant, marqué **« à confirmer par
  un expert »** de façon visible, et blocage des opérations qui en dépendent. Jamais une
  déduction à partir des factures.

## Lot 5 — Le calendrier des échéances

`ref.fiscal_obligations` est chargée. Écris la résolution d'échéance et **modélise le mode de
dépôt** : une personne morale a 28 jours, la même qui télédéclare n'en a plus que 20. C'est
une réduction introduite par la LF 2024, vérifiée dans quatre codes (art. 18-IV-1 CTVA,
art. 52-IV CIRPPIS, art. 39-II CFL, art. 119-III CDET). Un calendrier qui ignore le mode de
dépôt fera rater des échéances précisément à ceux qui se sont modernisés.

## Lot 6 — Le corpus juridique et sa file d'ingestion

`db/seed/file_ingestion_tn.sql` charge **788 documents** à ingérer, chacun vérifié : l'URL a
répondu, la langue a été mesurée sur le fichier et non déduite du libellé du lien.

L'ordre n'est pas chronologique. La prescription borne ce qui est opposable :

| Priorité | Contenu | Documents |
|---|---|---|
| 1 | Éditions consolidées 2025-2026 des codes — la loi applicable | 12 |
| 2 | Lois de finances 2021-2026 | 9 |
| 3 | Notes communes 2021-2026 — la doctrine encore opposable | 114 |
| 4-5 | Archive antérieure | 653 |

**Les 135 premiers suffisent au moteur.** Ne lance pas les 788 : tu paierais 5 200 pages d'OCR
pour de la valeur historique.

### Deux points non négociables

1. **Le modèle segmente, le code extrait.** Le prompt fourni renvoie des frontières
   (`ligne_debut`, `ligne_fin`), pas du texte. C'est ton code qui découpe la source, calcule le
   `source_sha256` et enregistre. Un modèle qui recopie un texte et en compte ensuite les mots
   ne prouve rien — il compte ce qu'il a produit.
2. **`open_issues` n'est pas décoratif.** Une convention dont la date de signature est laissée
   en blanc doit arriver là, pas entrer en base comme « en vigueur ». Le cas s'est présenté :
   la convention Tunisie-Allemagne en circulation porte « *Fait à Tunis, le ______* ».

### Ce que le collecteur doit savoir avant d'être écrit

Lis `docs/decisions/2026-08-31-corpus-juridique-inventaire.md` en entier. En résumé :

- **L'URL du PDF n'est pas dérivable** — elle doit être extraite du contenu de la fiche, jamais
  construite. Le mois du chemin est celui du versement, pas celui de la note.
- **Les pages HTML de catégorie sont inutilisables pour compter** : la liste est rendue côté
  client depuis un dump global. Seule l'API REST donne un compte exact.
- **Le flux RSS évident ne se déclenchera jamais** : le terme parent n'a aucun document
  attaché. La veille passe par `modified_after` sur l'API, ou par le `lastmod` du sitemap.
- **Les slugs d'année n'ont pas de convention stable** — résous l'année par l'arbre des
  catégories, jamais en construisant le slug.
- **102 PDF sur 685 sont des scans sans couche texte** — OCR **bilingue français-arabe**
  obligatoire, sinon 15 % du corpus est muet.
- **Un trou de numérotation n'est pas une note manquante.** 2020 saute de la note 19 à la 28.
  Un contrôle « 1 à max » produirait une trentaine de faux positifs.

### Le point qui décide de l'avenir du pipeline

Le corpus bascule vers l'arabe, et vite : 8 notes sur 21 en 2024, 8 sur 15 en 2025,
**17 sur 17 en 2026**. La LF 2026 aussi. Un pipeline français perdrait la totalité du millésime
courant. L'OCR et la segmentation doivent être bilingues **dès le premier jour**, pas
« plus tard ».

Une compensation utile : le JORT publie une **traduction française officielle de la LF 2026**,
161 pages en texte réel, là où les deux portails fiscaux ne servent que l'arabe.

### pgvector

`legal.article_versions` est le point d'attache des chunks. Si l'extension n'est pas installée,
installe-la ou retire le schéma — le contournement dans `charger.ps1` qui remplace
`vector(768)` par `real[]` et supprime l'index HNSW doit disparaître dans les deux cas.

## Lot 7 — Ce qui doit attendre

Ne construis pas maintenant : les déclarations, le tableau de détermination du résultat
fiscal, le calcul d'IS. Ils dépendent de paramètres que la lecture n'a **pas** établis —
notamment les taux maximaux d'amortissement admis en déduction, sans lesquels la divergence
comptable/fiscal n'est pas calculable.

Attention à ne pas confondre : le schéma `LIQUIDATION_TVA` livré au chantier comptable ne
calcule aucune taxe, il totalise des lignes déjà comptabilisées. Il passe maintenant.

---

## Règles de travail

- Zéro hardcoding, zéro stub, zéro placeholder, zéro doublon. Un taux de TVA en dur « pour
  faire passer les tests » est exactement le défaut que ce chantier corrige.
- Les treize paramètres `non_trouve` restent en base **sans valeur**. Ne les complète pas :
  leur rôle est de rendre l'absence visible.
- Chaque migration idempotente et rejouable.
- Ne réponds pas « fait ». Réponds avec les comptages — 454 paramètres, 43 obligations,
  8 tranches, 0 violation de citation — la liste des six tests et leur résultat, et ce que
  tu n'as pas touché.
