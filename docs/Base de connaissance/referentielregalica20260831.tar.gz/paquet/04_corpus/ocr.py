#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Étape d'OCR — séparée, et volontairement.

102 PDF du corpus n'ont aucune couche texte : ce sont des scans, concentrés sur 2015-2023.
Sans OCR bilingue français-arabe, 15 % du corpus est muet.

Le résultat de l'OCR ne doit JAMAIS être confondu avec un texte natif : il est marqué
comme tel (origine='ocr'), parce qu'un OCR se trompe et qu'une citation juridique tirée
d'un OCR non relu n'est pas opposable.
"""
import os, sys, hashlib, time
import psycopg2, psycopg2.extras
import fitz, pytesseract
from PIL import Image
import io

DSN   = os.environ.get("REGALICA_DSN", "postgres:///regalica_paquet")
CACHE = os.environ.get("REGALICA_CACHE", "/tmp/regalica/pipeline/cache")
DPI   = 200

def ocr_pdf(chemin, langue):
    lang = {"ar": "ara", "fr": "fra", "fr+ar": "fra+ara"}.get(langue, "fra+ara")
    doc = fitz.open(chemin); pages = []
    for p in doc:
        natif = p.get_text("text")
        if len(natif.strip()) >= 20:
            pages.append(natif); continue
        pix = p.get_pixmap(dpi=DPI)
        img = Image.open(io.BytesIO(pix.tobytes("png")))
        pages.append(pytesseract.image_to_string(img, lang=lang))
    doc.close()
    return "\n".join(pages), lang

def main():
    cn = psycopg2.connect(DSN); cn.autocommit = False
    cur = cn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("alter table legal.documents add column if not exists origine_texte text not null default 'natif';")
    cur.execute("comment on column legal.documents.origine_texte is "
                "'natif = couche texte du PDF. ocr = reconnaissance optique, sujette à erreur : "
                "une citation tirée d''un OCR non relu n''est pas opposable.';")
    cur.execute("""select d.queue_id, d.langue_mesuree, q.url_fichier, q.titre
                   from legal.documents d join legal.ingestion_queue q on q.id=d.queue_id
                   where d.besoin_ocr and d.origine_texte='natif'""")
    lot = cur.fetchall(); cn.commit()
    print(f"à OCRiser : {len(lot)} documents", flush=True)
    t0=time.time()
    for i, r in enumerate(lot, 1):
        dest = os.path.join(CACHE, hashlib.sha1(r["url_fichier"].encode()).hexdigest() + ".pdf")
        try:
            txt, lang = ocr_pdf(dest, r["langue_mesuree"])
            cur.execute("""update legal.documents
                           set texte=%s, caracteres=%s, origine_texte='ocr' where queue_id=%s""",
                        (txt, len(txt), r["queue_id"]))
        except Exception as ex:
            cur.execute("update legal.ingestion_queue set echec_motif=%s where id=%s",
                        (f"OCR: {type(ex).__name__}: {ex}"[:400], r["queue_id"]))
        if i % 5 == 0:
            cn.commit(); print(f"  {i}/{len(lot)}  {time.time()-t0:.0f}s", flush=True)
    cn.commit(); print(f"terminé en {time.time()-t0:.0f}s", flush=True)

if __name__ == "__main__":
    main()
