#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Regalica Office — pipeline d'ingestion du corpus juridique.

PRINCIPE FONDATEUR : le modèle segmente, le CODE extrait.
Ce script télécharge, extrait le texte, calcule l'empreinte SHA-256 et enregistre.
Aucun modèle de langage ne recopie ici un texte qui doit rester verbatim : un modèle
qui retape un article et en compte ensuite les mots ne prouve rien, il compte ce qu'il
a produit. L'empreinte est calculée sur le fichier téléchargé, par du code déterministe.

Reprenable : chaque document passe de 'a_faire' à 'ingere' ou 'echec' avec son motif.
Relancer le script ne retraite que ce qui reste.
"""
import hashlib, os, re, sys, time, unicodedata
from concurrent.futures import ThreadPoolExecutor
import urllib.request, urllib.error, urllib.parse
import psycopg2, psycopg2.extras
import fitz  # PyMuPDF

DSN     = os.environ.get("REGALICA_DSN", "postgres:///regalica_paquet")
CACHE   = os.environ.get("REGALICA_CACHE", "/tmp/regalica/pipeline/cache")
PRIO    = int(os.environ.get("REGALICA_PRIORITE_MAX", "3"))
PARALL  = int(os.environ.get("REGALICA_PARALLELISME", "8"))
UA      = "Regalica-Office/1.0 (ingestion corpus juridique; contact cabinet)"
os.makedirs(CACHE, exist_ok=True)

# --- détection de script : l'arabe fait foi, il ne doit jamais passer pour du bruit ---
def profil_langue(txt):
    ar = sum(1 for c in txt if '؀' <= c <= 'ۿ')
    la = sum(1 for c in txt if c.isalpha() and c.isascii())
    tot = ar + la
    if tot < 40:  return "indetermine", ar, la
    if ar / tot > 0.30: return "ar", ar, la
    if la / tot > 0.70: return "fr", ar, la
    return "fr+ar", ar, la

def encoder_url(url):
    """Le portail sert des fichiers dont le nom contient des « ° » et de l'arabe.
    urllib exige un chemin percent-encodé : sans cela, 109 documents sur 135 échouent
    sur une UnicodeEncodeError qui n'a rien à voir avec le réseau."""
    p = urllib.parse.urlsplit(url)
    return urllib.parse.urlunsplit((
        p.scheme, p.netloc.encode("idna").decode("ascii"),
        urllib.parse.quote(p.path, safe="/%"),
        urllib.parse.quote(p.query, safe="=&%"), p.fragment))

def telecharger(url, dest, essais=3):
    """Lecture par blocs et reprise sur IncompleteRead : deux codes consolidés dépassent
    50 Mo et le serveur coupe la connexion avant la fin."""
    dernier = None
    for n in range(essais):
        try:
            req = urllib.request.Request(encoder_url(url), headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=180) as r, open(dest, "wb") as f:
                while True:
                    bloc = r.read(1 << 20)
                    if not bloc: break
                    f.write(bloc)
            if os.path.getsize(dest) > 0:
                return os.path.getsize(dest)
            dernier = "fichier vide"
        except Exception as ex:
            dernier = f"{type(ex).__name__}: {ex}"
            time.sleep(2 * (n + 1))
    raise RuntimeError(dernier)

def extraire(chemin):
    """Retourne (texte, pages, pages_sans_texte). N'OCRise pas ici : l'OCR est une étape
    séparée, coûteuse, et son résultat ne doit pas être confondu avec un texte natif."""
    doc = fitz.open(chemin)
    morceaux, vides = [], 0
    for p in doc:
        t = p.get_text("text")
        if len(t.strip()) < 20: vides += 1
        morceaux.append(t)
    n = doc.page_count
    doc.close()
    return "\n".join(morceaux), n, vides

def traiter(row):
    doc_id, url, titre, langue_annoncee = row["id"], row["url_fichier"], row["titre"], row["langue"]
    dest = os.path.join(CACHE, hashlib.sha1(url.encode()).hexdigest() + ".pdf")
    try:
        if not os.path.exists(dest) or os.path.getsize(dest) == 0:
            telecharger(url, dest)
        sha = hashlib.sha256(open(dest, "rb").read()).hexdigest()
        texte, pages, vides = extraire(dest)
        langue, ar, la = profil_langue(texte)
        besoin_ocr = vides > 0
        return dict(id=doc_id, statut="ingere", sha=sha, pages=pages, texte=texte,
                    langue=langue, langue_annoncee=langue_annoncee, pages_vides=vides,
                    besoin_ocr=besoin_ocr, motif=None)
    except Exception as ex:
        return dict(id=doc_id, statut="echec", motif=f"{type(ex).__name__}: {ex}"[:400],
                    sha=None, pages=None, texte="", langue=None, langue_annoncee=langue_annoncee,
                    pages_vides=None, besoin_ocr=None)

def main():
    cn = psycopg2.connect(DSN); cn.autocommit = False
    cur = cn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
    cur.execute("""
      create table if not exists legal.documents (
        queue_id       uuid primary key references legal.ingestion_queue(id),
        sha256         char(64) not null,
        pages          int,
        pages_sans_texte int,
        langue_mesuree text,
        langue_annoncee text,
        besoin_ocr     boolean not null default false,
        caracteres     int,
        texte          text,
        ingere_le      timestamptz not null default now()
      );
      comment on table legal.documents is
        'Texte extrait PAR DU CODE, avec son empreinte. Aucun modèle n''a recopié ce texte.';
      comment on column legal.documents.langue_mesuree is
        'Mesurée sur le contenu extrait, jamais déduite du libellé du lien du portail.';
    """)
    cur.execute("""select id, url_fichier, titre, langue from legal.ingestion_queue
                   where statut='a_faire' and url_fichier is not null and priorite <= %s
                   order by priorite, annee desc""", (PRIO,))
    lot = cur.fetchall(); cn.commit()
    print(f"à traiter : {len(lot)} documents (priorité <= {PRIO})", flush=True)
    t0 = time.time(); ok = ko = 0
    with ThreadPoolExecutor(max_workers=PARALL) as ex:
        for i, r in enumerate(ex.map(traiter, lot), 1):
            if r["statut"] == "ingere":
                cur.execute("""insert into legal.documents
                    (queue_id,sha256,pages,pages_sans_texte,langue_mesuree,langue_annoncee,
                     besoin_ocr,caracteres,texte)
                    values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    on conflict (queue_id) do update set sha256=excluded.sha256""",
                    (r["id"], r["sha"], r["pages"], r["pages_vides"], r["langue"],
                     r["langue_annoncee"], r["besoin_ocr"], len(r["texte"]), r["texte"]))
                cur.execute("update legal.ingestion_queue set statut='ingere', sha256_source=%s, ingere_le=now() where id=%s",
                            (r["sha"], r["id"])); ok += 1
            else:
                cur.execute("update legal.ingestion_queue set statut='echec', echec_motif=%s where id=%s",
                            (r["motif"], r["id"])); ko += 1
            if i % 20 == 0:
                cn.commit(); print(f"  {i}/{len(lot)}  ok={ok} echec={ko}  {time.time()-t0:.0f}s", flush=True)
    cn.commit()
    print(f"terminé : {ok} ingérés, {ko} échecs, {time.time()-t0:.0f}s", flush=True)
    cur.close(); cn.close()

if __name__ == "__main__":
    main()
