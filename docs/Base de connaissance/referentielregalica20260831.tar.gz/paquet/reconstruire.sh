#!/usr/bin/env bash
# Reconstruit tout le référentiel Regalica dans une base vierge, dans l'ordre.
# Usage : ./reconstruire.sh "postgres://user:mdp@host:5432/base"
# Le mot de passe ne doit jamais passer par la ligne de commande en production : PGPASSWORD.
set -euo pipefail
DB="${1:?donnez une URL de connexion}"
for f in 01_socle/00_bootstrap.sql \
         01_socle/01_migration_socle.sql \
         02_comptable/10_plan_officiel.sql \
         02_comptable/11_plan_extensions.sql \
         02_comptable/12_roles_liaisons_schemas.sql \
         03_fiscal/30_ddl_fiscal.sql \
         03_fiscal/31_parametres.sql \
         03_fiscal/32_obligations.sql \
         04_corpus/40_file_ingestion.sql ; do
  echo ">>> $f"
  psql "$DB" -q -v ON_ERROR_STOP=1 -f "$f"
done
echo ">>> vérification"
psql "$DB" -f verifier.sql
